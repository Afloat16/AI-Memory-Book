"""Current decisions can change within a long engineering conversation."""

from __future__ import annotations

import unittest

from memory_book import MemoryBook


def training_session(project="trainer", session_id="s1", *, date="2026-10-01T00:00:00Z"):
    return {
        "project": project,
        "session_id": session_id,
        "task_id": "gradient-memory",
        "title": "Gradient accumulation steps",
        "created_at": date,
        "messages": [
            {"role": "user", "content": "Gradient accumulation steps?"},
            {"role": "assistant", "content": "Gradient accumulation steps are 8. "
             + "gradient accumulation steps. " * 28},
            {"role": "user", "content": "Gradient accumulation steps?"},
            {"role": "assistant", "content": "Gradient accumulation steps are now 2. "
             "The former value 8 caused divergence and is no longer valid."},
        ],
    }


class CurrentTurnRecallTests(unittest.TestCase):
    def test_default_segmentation_recalls_later_revision_in_same_session(self):
        with MemoryBook(":memory:") as book:
            book.ingest(training_session())
            result = book.recall("current gradient accumulation steps", project="trainer",
                                 limit=1, budget_chars=500, use_cache=False)
            self.assertIn("steps are now 2", result["context"])
            self.assertEqual({ref["turn_index"] for ref in result["results"][0]["source_refs"]}, {1})
            # Recency remains evidence ordering, not an authoritative state resolver.
            self.assertTrue(result["warnings"])

    def test_historical_and_unqualified_queries_keep_their_relevance_order(self):
        with MemoryBook(":memory:") as book:
            book.ingest(training_session())
            for query in ("gradient accumulation steps", "original gradient accumulation steps",
                          "current gradient accumulation steps as of 2026"):
                with self.subTest(query=query):
                    result = book.recall(query, project="trainer", limit=1, budget_chars=500)
                    self.assertEqual(result["results"][0]["source_refs"][0]["turn_index"], 0)

    def test_chinese_revision_respects_project_scope_with_duplicate_session_ids(self):
        with MemoryBook(":memory:", max_page_chars=384, min_page_chars=80) as book:
            for project, value in (("训练甲", "2"), ("训练乙", "4")):
                book.ingest({
                    "project": project, "session_id": "训练讨论", "task_id": "显存预算",
                    "title": "梯度累积步数", "created_at": "2026-10-01T00:00:00Z",
                    "messages": [
                        {"role": "user", "content": "梯度累积步数怎么设置？"},
                        {"role": "assistant", "content": "梯度累积步数设为8。" + "梯度累积步数。" * 48},
                        {"role": "user", "content": "梯度累积步数怎么设置？"},
                        {"role": "assistant", "content": f"梯度累积步数改为{value}，旧值已因收敛测试失败而弃用。"},
                    ],
                })
            for project, value in (("训练甲", "2"), ("训练乙", "4")):
                with self.subTest(project=project):
                    result = book.recall("当前梯度累积步数", project=project, limit=1, budget_chars=400)
                    self.assertIn(f"步数改为{value}", result["context"])
                    self.assertEqual({ref["project"] for hit in result["results"]
                                      for ref in hit["source_refs"]}, {project})
                    self.assertEqual(result["results"][0]["source_refs"][0]["turn_index"], 1)

    def test_turn_numbers_never_override_chronology_between_sessions(self):
        with MemoryBook(":memory:", segmentation="turn") as book:
            book.ingest(training_session())
            later = training_session(session_id="later", date="2026-11-01T00:00:00Z")
            later["messages"] = [
                {"role": "user", "content": "Gradient accumulation steps?"},
                {"role": "assistant", "content": "Gradient accumulation steps are now 3."},
            ]
            book.ingest(later)
            result = book.recall("current gradient accumulation steps", project="trainer",
                                 limit=3, budget_chars=4000)
            self.assertEqual(result["results"][0]["source_refs"][0]["session_id"], "later")
            same_session_turns = [hit["source_refs"][0]["turn_index"] for hit in result["results"]
                                  if hit["source_refs"][0]["session_id"] == "s1"]
            self.assertEqual(same_session_turns, [1, 0])

    def test_same_turn_continuations_keep_their_relevance_order(self):
        with MemoryBook(":memory:", max_page_chars=128, min_page_chars=0) as book:
            source = training_session()
            source["messages"] = source["messages"][:2]
            book.ingest(source)
            plain = book.recall("gradient accumulation steps", project="trainer", limit=3, use_cache=False)
            current = book.recall("current gradient accumulation steps", project="trainer", limit=3, use_cache=False)
            self.assertEqual([hit["id"] for hit in current["results"]],
                             [hit["id"] for hit in plain["results"]])
            self.assertTrue(all(ref["turn_index"] == 0 for hit in current["results"]
                                for ref in hit["source_refs"]))

    def test_reordered_evidence_keeps_budgets_and_original_source_coordinates(self):
        with MemoryBook(":memory:") as book:
            book.ingest(training_session())
            for budget in (150, 500, 4000):
                with self.subTest(budget=budget):
                    result = book.recall("current gradient accumulation steps", project="trainer",
                                         limit=1, budget_chars=budget)
                    self.assertLessEqual(result["context_chars"], budget)
                    self.assertEqual(result["context_chars"], len(result["context"]))
                    hit = result["results"][0]
                    original = book.read(hit["id"])["content"]
                    start, end = hit["excerpt_spans"][0]
                    self.assertEqual(hit["text"], ("…" if start else "") + original[start:end]
                                     + ("…" if end < len(original) else ""))
                    self.assertTrue(all(ref["turn_index"] == 1 for ref in hit["source_refs"]))
                    cached = book.recall("current gradient accumulation steps", project="trainer",
                                         limit=1, budget_chars=budget)
                    self.assertTrue(cached["cache_hit"])
                    self.assertEqual(cached["context"], result["context"])


if __name__ == "__main__":
    unittest.main()
