"""Audit retained engineering benchmark outputs; never perform retrieval or ingest."""
from __future__ import annotations

import base64
import hashlib
import json
import pathlib
import subprocess
import sys
from collections import Counter
from datetime import datetime, timezone

ROOT = pathlib.Path(__file__).resolve().parents[1]
REPO = ROOT / "AI-Memory-Book"
EVIDENCE = ROOT / "evidence"
sys.path.insert(0, str(REPO))
sys.path.insert(0, str(REPO / "src"))
from benchmarks import engineering_workflow as workflow
from benchmarks import engineering_components as components


def read_json(path):
    return json.loads(path.read_text())


def read_jsonl(path):
    return [json.loads(line) for line in path.read_text().splitlines() if line]


def file_sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def git_head(path):
    return subprocess.check_output(["git", "-C", str(path), "rev-parse", "HEAD"], text=True).strip()


checks = []


def check(name, passed, details=None):
    value = {"check": name, "passed": bool(passed)}
    if details is not None:
        value["details"] = details
    checks.append(value)


names = [f"{version}-engineering-{track}" for track in ("workflow", "components")
         for version in ("baseline", "current")]
runs = {}
input_hashes = {}
for name in names:
    directory = EVIDENCE / name
    paths = [p for p in sorted(directory.iterdir()) if p.suffix in {".json", ".jsonl", ".md"}]
    for path in paths:
        input_hashes[str(path.relative_to(ROOT))] = file_sha(path)
    runs[name] = {"report": read_json(directory / "report.json"),
                  "rows": read_jsonl(directory / "raw.jsonl"),
                  "dataset": read_json(directory / "dataset.json"), "directory": directory}

baseline_runtime = runs["baseline-engineering-workflow"]["report"]["runtime"]
current_runtime = runs["current-engineering-workflow"]["report"]["runtime"]
manifest_entries = {}
manifest_files = [EVIDENCE / name for name in ("upgrade-initial-input.json", "upgrade-rest-input.json")]
for path in manifest_files:
    input_hashes[str(path.relative_to(ROOT))] = file_sha(path)
    for entry in read_json(path):
        if entry["path"].startswith("src/memory_book/") and entry["path"].endswith(".py"):
            manifest_entries[entry["path"]] = entry
manifest_proof = []
for relative, expected_sha in baseline_runtime["files"].items():
    path = "src/memory_book/" + relative
    entry = manifest_entries.get(path)
    if entry is None:
        check("baseline upstream manifest includes " + path, False)
        continue
    content = base64.b64decode(entry["content"]) if entry["encoding"] == "base64" else entry["content"].encode()
    blob_sha = hashlib.sha1(b"blob " + str(len(content)).encode() + b"\0" + content).hexdigest()
    sha256 = hashlib.sha256(content).hexdigest()
    check("upstream source blob and runtime match: " + path,
          blob_sha == entry["sha"] and sha256 == expected_sha)
    manifest_proof.append({"path": path, "git_blob_sha": blob_sha, "sha256": sha256})

evaluator_sha = file_sha(REPO / "benchmarks/engineering_workflow.py")
component_identity = components.source_identity()
all_cases = {case["id"]: case for step in runs[names[0]]["dataset"] for case in step["cases"]}
check("original workload has 80 unique cases", len(all_cases) == 80)
check("all four retained datasets are identical",
      all(run["dataset"] == runs[names[0]]["dataset"] for run in runs.values()))
run_audits = {}

for name, run in runs.items():
    report, rows, dataset, directory = (run[k] for k in ("report", "rows", "dataset", "directory"))
    is_components = name.endswith("components")
    backends = ("book", "billion") if is_components else ("book", "flat", "recent_history", "no_memory")
    budgets = report["settings"]["budgets_chars"]
    repeats = report["settings"]["repeats"]
    check(name + ": completed", report["status"] == "completed")
    check(name + ": canonical dataset hash", workflow.sha(dataset) == report["dataset_sha256"])
    check(name + ": runtime map hash", workflow.sha(report["runtime"]["files"]) == report["runtime"]["sha256"])
    check(name + ": unchanged runtime throughout run", report["runtime_unchanged"]
          and report["runtime_final_sha256"] == report["runtime"]["sha256"])
    runtime_root = pathlib.Path(report["runtime"]["imported_runtime_root"])
    actual_runtime_files = {str(p.relative_to(runtime_root)): file_sha(p) for p in sorted(runtime_root.rglob("*.py"))}
    check(name + ": runtime files still match retained identity", actual_runtime_files == report["runtime"]["files"])
    expected_evaluator = component_identity if is_components else evaluator_sha
    declared_evaluator = report["evaluator"] if is_components else report["evaluator_sha256"]
    check(name + ": evaluator identity and stability", expected_evaluator == declared_evaluator
          and report["evaluator_unchanged"] and (not is_components
          or report["evaluator_final_sha256"] == component_identity["sha256"]))
    expected_keys = {(case_id, backend, budget) for case_id in all_cases for backend in backends for budget in budgets}
    row_keys = [(row["case_id"], row["backend"], row["budget_chars"]) for row in rows]
    check(name + ": exact case/backend/budget coverage", len(row_keys) == len(set(row_keys))
          and set(row_keys) == expected_keys)
    check(name + ": report summary recomputes exactly", workflow.summarize(rows) == report["summary"])
    by_category = {category: workflow.summarize([row for row in rows if row["category"] == category])
                   for category in sorted({row["category"] for row in rows})}
    check(name + ": category summaries recompute exactly", by_category == report["by_category"])

    visible, source_by_checkpoint, visible_count = {}, {}, {}
    for step in dataset:
        for session in step["sessions"]:
            visible[(session["project"], session["session_id"])] = session
        # Construct directly from stored messages without using the runtime or retrieval.
        source_by_checkpoint[step["checkpoint"]] = {
            (s["project"], s["session_id"], 0): "\n\n".join(
                f"{m['role'].upper()}: {m['content']}" for m in s["messages"])
            for s in visible.values()}
        visible_count[step["checkpoint"]] = len(visible)
    row_errors = []
    returned_hits = source_refs = source_characters = 0
    for row in rows:
        case = all_cases[row["case_id"]]
        response = row["response"]
        sources = source_by_checkpoint[row["checkpoint"]]
        identity = [row["case_id"], row["backend"], row["budget_chars"]]
        if any(row[key] != case[key] for key in ("query", "project", "checkpoint", "category")):
            row_errors.append([identity, "case metadata mismatch"])
        if len(row["latency_ms"]) != repeats or not row["repeat_outputs_equal"]:
            row_errors.append([identity, "missing repetition or unstable output"])
        rescored = workflow.score(case, response, sources, row["budget_chars"])
        if rescored != row["score"]:
            row_errors.append([identity, "stored score differs from rescored source evidence"])
        if rescored["source_errors"] or not rescored["within_budget"]:
            row_errors.append([identity, rescored["source_errors"] or "over character budget"])
        if "context_chars" in response and response["context_chars"] != len(response["context"]):
            row_errors.append([identity, "reported character count differs"])
        if not is_components:
            stable_response = {k: v for k, v in response.items() if k != "latency_ms"}
            if row["output_sha256"] != [workflow.sha(stable_response)] * repeats:
                row_errors.append([identity, "retained first response/repeat digest mismatch"])
            if row["visible_sessions"] != visible_count[row["checkpoint"]]:
                row_errors.append([identity, "chronological visibility differs"])
        for hit in response["results"]:
            returned_hits += 1
            for ref in hit.get("source_refs", []):
                source_refs += 1
                source_characters += ref["turn_end"] - ref["turn_start"]
    check(name + ": all raw outputs rescore, respect budget and prove source spans", not row_errors, row_errors)
    run_audits[name] = {
        "raw_rows": len(rows), "unique_cases": len({r["case_id"] for r in rows}),
        "budgets_chars": budgets, "backends": backends, "repetitions_per_query": repeats,
        "returned_hits_checked": returned_hits, "source_references_checked": source_refs,
        "referenced_source_characters_checked": source_characters,
        "budget_violations": sum(not r["score"]["within_budget"] for r in rows),
        "source_validation_failures": sum(bool(r["score"]["source_errors"]) for r in rows),
        "repeat_output_changes": sum(not r["repeat_outputs_equal"] for r in rows),
        "settings": report["settings"], "environment": report["environment"],
        "runtime_sha256": report["runtime"]["sha256"],
        "evaluator_sha256": component_identity["sha256"] if is_components else evaluator_sha,
        "created_at": report["created_at"],
    }
    if not is_components:
        continue
    binding = read_json(directory / "binding.json")
    check(name + ": binding agrees with completed report", all(binding[k] == report[k]
          for k in ("version", "created_at", "dataset_sha256", "runtime", "evaluator", "settings", "upstream_lock")))
    documents_by_checkpoint = {}
    doc_errors = []
    for checkpoint in report["checkpoints"]:
        number = checkpoint["checkpoint"]
        docs = read_json(directory / f"documents-{number}.json")
        documents_by_checkpoint[number] = {d["id"]: d for d in docs}
        fields = [{key: doc[key] for key in ("id", "project", "title", "text")} for doc in docs]
        if (checkpoint != read_json(directory / f"checkpoint-{number}.json")
                or workflow.sha(docs) != checkpoint["documents_sha256"]
                or workflow.sha(fields) != checkpoint["supplied_search_fields_sha256"]
                or len(docs) != checkpoint["documents"] or len(docs) != visible_count[number]):
            doc_errors.append([number, "retained checkpoint/export identity differs"])
        sources = source_by_checkpoint[number]
        seen = []
        for doc in docs:
            refs = doc["source_refs"]
            if len(refs) != 1:
                doc_errors.append([number, doc["id"], "not a complete one-turn page"])
                continue
            ref = refs[0]
            source_id = (ref["project"], ref["session_id"], ref["turn_index"])
            seen.append(source_id)
            if (source_id not in sources or doc["text"] != sources[source_id]
                    or doc["project"] != source_id[0] or ref["turn_start"] != 0
                    or ref["turn_end"] != len(sources[source_id])):
                doc_errors.append([number, doc["id"], "export body/provenance differs from visible source"])
        if len(seen) != len(set(seen)) or set(seen) != set(sources):
            doc_errors.append([number, "visible sources not exactly covered"])
    check(name + ": full page inputs and visibility verify", not doc_errors, doc_errors)
    native = read_jsonl(directory / "native.jsonl")
    native_map = {(r["case_id"], r["backend"]): r for r in native}
    check(name + ": complete native case/backend coverage", len(native) == len(native_map) == 160
          and set(native_map) == {(case_id, backend) for case_id in all_cases for backend in backends})
    native_errors = []
    for row in native:
        case = all_cases[row["case_id"]]
        docs = documents_by_checkpoint[row["checkpoint"]]
        if any(row[key] != case[key] for key in ("query", "project", "checkpoint")):
            native_errors.append([row["case_id"], row["backend"], "case metadata differs"])
        if [s["repetition"] for s in row["samples"]] != list(range(repeats)):
            native_errors.append([row["case_id"], row["backend"], "missing full native repetitions"])
        for sample in row["samples"]:
            if workflow.sha(components.stable(sample["native"])) != sample["native_sha256"]:
                native_errors.append([row["case_id"], row["backend"], "native content hash differs"])
            mapped = components.mapped_ids(sample["native"], row["backend"], docs, row["project"])
            if mapped != sample["hit_ids"]:
                native_errors.append([row["case_id"], row["backend"], "native candidates differ"])
            if row["backend"] == "book":
                errors = workflow.source_errors(sample["native"], source_by_checkpoint[row["checkpoint"]], row["project"])
                if errors:
                    native_errors.append([row["case_id"], row["backend"], errors])
        if len({s["native_sha256"] for s in row["samples"]}) != 1:
            native_errors.append([row["case_id"], row["backend"], "native output changed"])
    for row in rows:
        native_row = native_map[(row["case_id"], row["backend"])]
        first = native_row["samples"][0]
        repacked = components.common_pack(first["hit_ids"], documents_by_checkpoint[row["checkpoint"]],
                                         row["project"], row["budget_chars"])
        if repacked != row["response"] or first["native_sha256"] != row["native_first_output_sha256"]:
            native_errors.append([row["case_id"], row["backend"], row["budget_chars"], "whole-block packing/digest differs"])
        if row["latency_ms"] != [s["adapter_call_ms"] for s in native_row["samples"]]:
            native_errors.append([row["case_id"], row["backend"], "timing does not match reused native samples"])
    check(name + ": all native responses and common packing verify", not native_errors, native_errors)
    run_audits[name].update(native_query_backend_pairs=len(native),
        full_native_responses_checked=sum(len(r["samples"]) for r in native),
        exported_documents_by_checkpoint={str(k): len(v) for k, v in documents_by_checkpoint.items()},
        upstream_lock=report["upstream_lock"])

for track in ("workflow", "components"):
    old, new = (runs[f"{version}-engineering-{track}"]["report"] for version in ("baseline", "current"))
    check(track + ": before/after protocol settings equal", old["settings"] == new["settings"])
    check(track + ": before/after declared environment equal", old["environment"] == new["environment"])
    if track == "components":
        check("components: before/after upstream lock equal", old["upstream_lock"] == new["upstream_lock"])
        check("components: before/after complete search inputs equal at all checkpoints", all(
            a["documents_sha256"] == b["documents_sha256"]
            and a["supplied_search_fields_sha256"] == b["supplied_search_fields_sha256"]
            for a, b in zip(old["checkpoints"], new["checkpoints"])))
        a = read_jsonl(runs["baseline-engineering-components"]["directory"] / "native.jsonl")
        b = read_jsonl(runs["current-engineering-components"]["directory"] / "native.jsonl")
        native_digest = lambda rows: {(r["case_id"], s["repetition"]): s["native_sha256"]
            for r in rows if r["backend"] == "billion" for s in r["samples"]}
        check("components: billion full native outputs unchanged before/after", native_digest(a) == native_digest(b))
for version in ("baseline", "current"):
    check(version + ": same runtime identity in both separate tracks",
          runs[f"{version}-engineering-workflow"]["report"]["runtime"] ==
          runs[f"{version}-engineering-components"]["report"]["runtime"])


def metric_rows(rows):
    result = []
    for cell in workflow.summarize(rows):
        selected = [r["score"] for r in rows if r["backend"] == cell["backend"] and r["budget_chars"] == cell["budget_chars"]]
        result.append({**cell, "required_evidence_spans": sum(s["required_evidence"] for s in selected),
            "matched_evidence_spans": sum(s["matched_evidence"] for s in selected),
            "complete_evidence_cases": sum(s["complete_evidence"] for s in selected),
            "fixed_consumer_passed_cases": sum(s.get("fixed_consumer", {}).get("all_passed", False) for s in selected)})
    return result


def paired(left_rows, right_rows, left_backend, right_backend, budget):
    left = {r["case_id"]: r for r in left_rows if r["backend"] == left_backend and r["budget_chars"] == budget}
    right = {r["case_id"]: r for r in right_rows if r["backend"] == right_backend and r["budget_chars"] == budget}
    assert set(left) == set(right) == set(all_cases)
    output = {"left_backend": left_backend, "right_backend": right_backend, "budget_chars": budget,
              "direction": "wins mean right succeeds and left fails", "cases": len(left)}
    for metric, eligible, get in [
        ("complete_evidence", lambda s: s["answerable"], lambda s: s["complete_evidence"]),
        ("fixed_consumer_policy", lambda s: "fixed_consumer" in s, lambda s: s["fixed_consumer"]["all_passed"]),
    ]:
        groups = {k: [] for k in ("wins", "losses", "unchanged_pass", "unchanged_fail")}
        for case_id in sorted(left):
            a, b = left[case_id]["score"], right[case_id]["score"]
            if not eligible(a):
                continue
            assert eligible(b)
            x, y = get(a), get(b)
            group = "wins" if y and not x else "losses" if x and not y else "unchanged_pass" if y else "unchanged_fail"
            groups[group].append(case_id)
        unchanged = sorted(groups["unchanged_pass"] + groups["unchanged_fail"])
        output[metric] = {"eligible_cases": sum(map(len, groups.values())),
            "wins": len(groups["wins"]), "losses": len(groups["losses"]), "unchanged": len(unchanged),
            "case_ids": {**groups, "unchanged": unchanged}}
    stale = {k: [] for k in ("newly_stale_only", "cleared_stale_only", "both_stale_only", "neither_stale_only")}
    for case_id in sorted(left):
        a, b = left[case_id]["score"]["stale_only"], right[case_id]["score"]["stale_only"]
        group = "newly_stale_only" if b and not a else "cleared_stale_only" if a and not b else "both_stale_only" if b else "neither_stale_only"
        stale[group].append(case_id)
    output["stale_only"] = {"left_count": sum(r["score"]["stale_only"] for r in left.values()),
        "right_count": sum(r["score"]["stale_only"] for r in right.values()),
        "counts": {k: len(v) for k, v in stale.items()}, "case_ids": stale}
    return output


before_after = {}
for track in ("workflow", "components"):
    old, new = (runs[f"{version}-engineering-{track}"]["rows"] for version in ("baseline", "current"))
    before_after[track] = [paired(old, new, backend, backend, budget)
        for backend in sorted({r["backend"] for r in new}) for budget in (1200, 2400)]
component_current = runs["current-engineering-components"]["rows"]
current_vs_billion = [paired(component_current, component_current, "billion", "book", budget) for budget in (1200, 2400)]
stale_ids = ["m4:training-online:chinese", "m4:training-batch:chinese"]
stale_details = []
for case_id in stale_ids:
    item = {"case": all_cases[case_id], "observations": []}
    for name, run in runs.items():
        for row in run["rows"]:
            if row["case_id"] == case_id and row["backend"] == "book":
                item["observations"].append({"run": name, "budget_chars": row["budget_chars"],
                    "score": row["score"], "context": row["response"]["context"],
                    "source_ids": sorted({r["session_id"] for h in row["response"]["results"] for r in h["source_refs"]})})
    stale_details.append(item)

check("all retained input artifacts unchanged during audit", all(file_sha(ROOT / p) == digest for p, digest in input_hashes.items()))
output = {
    "schema_version": 1, "audit": "retained-output-only; no benchmark, ingest, or retrieval rerun",
    "created_at": datetime.now(timezone.utc).isoformat(),
    "status": "passed" if all(c["passed"] for c in checks) else "failed",
    "source_identity": {
        "baseline": {"upstream_repository": "Afloat16/AI-Memory-Book",
            "upstream_ref": "a0de3f48a7f585393c9b32b49ffcd3d29e6a5f3e",
            "upstream_ref_provenance": "Parent fetched exact-ref GitHub contents; retained source content and returned Git blob SHA independently checked here.",
            "local_materialized_snapshot_commit": git_head(ROOT / "AI-Memory-Book-baseline"),
            "runtime": baseline_runtime, "verified_upstream_blob_mapping": manifest_proof},
        "current": {"local_commit": git_head(REPO), "published": False,
            "identity_basis": "Imported Python source-file SHA-256; local commit is not a published release or upstream link.",
            "runtime": current_runtime},
        "dataset_sha256": runs[names[0]]["report"]["dataset_sha256"],
        "workflow_evaluator_sha256": evaluator_sha, "components_evaluator_closure": component_identity},
    "metric_definitions": {
        "evidence_recall": "matched source-grounded required evidence spans / 80 required spans, across 72 answerable cases",
        "complete_evidence_rate": "all required source-grounded spans returned / 72 answerable cases",
        "fixed_consumer_all_checks_pass_rate": "all checks passed by a fixed handwritten policy consumer / 48 eligible cases; not autonomous coding success",
        "stale_only": "a labeled stale source quote was returned, with no required evidence matched; can worsen while complete/policy failures are unchanged",
        "budget": "Python Unicode character count, including output framing; not token count",
        "repetitions": "3 timing/stability repetitions of each query; not 3 independent quality cases"},
    "checks": checks, "integrity": {"checks_run": len(checks), "checks_failed": sum(not c["passed"] for c in checks),
        "raw_outputs_checked": sum(a["raw_rows"] for a in run_audits.values()),
        "full_component_native_responses_checked": sum(a.get("full_native_responses_checked", 0) for a in run_audits.values()),
        "workflow_repeat_record_scope": "First full response plus 3 matching retained digests; component track retains all 3 full native responses."},
    "run_audits": run_audits,
    "metrics": {name: metric_rows(run["rows"]) for name, run in runs.items()},
    "before_after_paired": before_after,
    "current_book_vs_billion_paired_components_only": current_vs_billion,
    "stale_only_risk_details": stale_details,
    "readme_ready_current_rows": {
        "native_excerpt_workflow": metric_rows(runs["current-engineering-workflow"]["rows"]),
        "whole_block_components": metric_rows(component_current)},
    "readme_risk_summary_zh": [
        "原生摘录轨道2400字符：Book完整证据70/72（97.2%）、固定策略消费46/48（95.8%）；完整证据不是80题的70题。",
        "共享整块轨道2400字符：Book70/72与46/48，billion-context64/72与40/48；逐题Book8胜2负，优势集中在历史决策题，两个中文split_policy题落后。",
        "共享整块轨道1200字符：Book58/72与34/48，billion-context64/72与40/48，逐题8胜14负；不能宣称所有预算下都优于对方。",
        "原生摘录轨道相较基线的两个新增成功均为training历史问题；两个中文split_policy旧失败现在变成stale-only，两个预算均由0升至2。",
        "这两个中文问题的固定消费者原先因无策略而弃答，现在分别选到过时row_modulo/whole_group，正确值应为whole_group/chronological；虽然完整证据和策略成功的布尔值仍为失败，错误形态确实恶化。",
        "原生摘录轨道和共享整块轨道的打包规则不同；禁止把原生摘录Book1200结果与共享整块billion结果拼成公平对照。",
        "8个标记为无证据的问题中，检索后端均返回非空上下文；本实验没有验证可靠拒答或生成答案的事实性。",
        "这是80个合成开发诊断问题，包含成对项目和固定策略消费者；没有LLM生成、真实开发者任务或生产环境成本评估。",
        "计时来自同机观测，运行时进程边界、输出组装和缓存不同；仅能按原报告解释，不是受控性能提升或完整产品速度比较。"],
    "track_boundaries": {
        "workflow": "Native Book/flat excerpts versus fixed recent-project-history/no-memory baselines; adaptive segmentation, top 5, no result cache.",
        "components": "Same full source-page bodies, project filter, top 5, native candidate order, shared whole-block packer; oversized blocks skipped. Native excerpts ignored.",
        "component_feature_limit": "Book retains hierarchy/FTS features; billion receives uniform assistant message title/body/project. Same source text does not mean equivalent indexed features or whole products.",
        "timing_limit": "Book native timer includes in-process Python context assembly. Billion has separate searchBlocks and persistent-JSON roundtrip times. Common pack reads an in-memory supplied fixture and excludes real decompression/follow-up reads. Processes restart at each checkpoint; results are reused across both budgets."},
    "input_artifact_sha256": input_hashes,
    "audit_script_sha256": file_sha(pathlib.Path(__file__)),
}
destination = EVIDENCE / "developer-validation-summary.json"
destination.write_text(json.dumps(output, ensure_ascii=False, indent=2, allow_nan=False) + "\n")
print(json.dumps({"path": str(destination), "status": output["status"], "checks": len(checks),
    "failures": [c for c in checks if not c["passed"]], "raw_outputs_checked": output["integrity"]["raw_outputs_checked"],
    "full_native_responses_checked": output["integrity"]["full_component_native_responses_checked"],
    "bytes": destination.stat().st_size, "sha256": file_sha(destination)}, ensure_ascii=False))
