#!/usr/bin/env python3
"""Recompute the read-only GitHub attribution audit from saved API metadata."""
from __future__ import annotations
import hashlib
import json
from collections import Counter, defaultdict, deque
from pathlib import Path

ROOT = Path(__file__).resolve().parent
BOT_EMAIL = "41898282+github-actions[bot]@users.noreply.github.com"

def is_bot(person):
    return person["name"] == "github-actions[bot]" or person["email"] == BOT_EMAIL

def main():
    inputs = sorted((ROOT / "inputs").glob("main-page-*.json"))
    assert len(inputs) == 10
    commits = [c for path in inputs for c in json.loads(path.read_text())]
    by_sha = {c["sha"]: c for c in commits}
    assert len(commits) == len(by_sha) == 972
    source = json.loads((ROOT / "main-source.json").read_text())
    assert commits[0]["sha"] == source["source_main_sha"]
    assert all(p["sha"] in by_sha for c in commits for p in c["parents"])
    author_bots = [c for c in commits if is_bot(c["commit"]["author"])]
    committer_bots = [c for c in commits if is_bot(c["commit"]["committer"])]
    affected = {}
    children = defaultdict(list)
    pending = {}
    for c in commits:
        pending[c["sha"]] = len(c["parents"])
        for parent in c["parents"]:
            children[parent["sha"]].append(c["sha"])
    queue = deque(sha for sha, n in pending.items() if n == 0)
    while queue:
        sha = queue.popleft()
        c = by_sha[sha]
        affected[sha] = (
            is_bot(c["commit"]["author"]) or is_bot(c["commit"]["committer"])
            or any(affected[p["sha"]] for p in c["parents"])
        )
        for child in children[sha]:
            pending[child] -= 1
            if pending[child] == 0:
                queue.append(child)
    assert len(affected) == len(by_sha)
    branches = json.loads((ROOT / "branches.json").read_text())["branches"]
    tags = json.loads((ROOT / "tags.json").read_text())["tags"]
    expected = json.loads((ROOT / "summary.json").read_text())
    actual = {
        "main_sha": source["source_main_sha"],
        "total": len(commits),
        "unique": len(by_sha),
        "authorBots": len(author_bots),
        "committerBots": len(committer_bots),
        "authorOnly": sum(not is_bot(c["commit"]["committer"]) for c in author_bots),
        "committerOnly": sum(not is_bot(c["commit"]["author"]) for c in committer_bots),
        "affectedMainCommits": sum(affected.values()),
        "branches": len(branches),
        "branchHeadsInMain": sum(b["sha"] in by_sha for b in branches),
        "affectedKnownBranches": sum(affected.get(b["sha"], False) for b in branches),
    }
    assert all(expected[key] == value for key, value in actual.items()), actual
    assert len(branches) == len({b["name"] for b in branches}) == 315
    assert len(tags) == len({t["ref"] for t in tags}) == 16
    affected_tags = sorted(t["ref"] for t in tags if affected.get(t["sha"], False))
    assert affected_tags == sorted(t["ref"] for t in expected["tags"] if t["affected"])
    assert len(affected_tags) == 13
    signatures = Counter(("verified" if c["commit"]["verification"]["verified"] else "unverified") + ":" + c["commit"]["verification"]["reason"] for c in author_bots)
    assert dict(signatures) == expected["botSignatures"] == {"unverified:unsigned": 600}
    affected_signed = [c["sha"] for c in commits if affected[c["sha"]] and c["commit"]["verification"]["verified"]]
    assert affected_signed == ["a0961f29dcdf3801d063e6d69bacaa1bde99e318"]
    projected = [
        {
            "sha": c["sha"], "tree_sha": c["commit"]["tree"]["sha"],
            "parents": [p["sha"] for p in c["parents"]],
            "author": c["commit"]["author"], "committer": c["commit"]["committer"],
            "message": c["commit"]["message"], "verification": c["commit"]["verification"],
            "author_login": c["author"]["login"] if c["author"] else None,
            "committer_login": c["committer"]["login"] if c["committer"] else None,
            "html_url": c["html_url"],
        }
        for c in commits
    ]
    (ROOT / "main-commits.json").write_text(json.dumps({**source, "commits": projected}, ensure_ascii=False, indent=2) + "\n")
    result = {
        "status": "passed", **actual, "affected_tag_count": len(affected_tags),
        "affected_tags": affected_tags, "affected_previously_verified_commits": affected_signed,
        "unresolved_parents": 0,
        "off_main_branch_heads_not_audited": len(branches) - actual["branchHeadsInMain"],
        "main_first_page_was_pinned_by_returned_head": True,
        "repository_mutations": 0,
    }
    (ROOT / "verification.json").write_text(json.dumps(result, indent=2) + "\n")
    manifest = []
    for path in sorted(ROOT.rglob("*")):
        if path.is_file() and path.name != "sha256-manifest.json":
            raw = path.read_bytes()
            manifest.append({"path": str(path.relative_to(ROOT)), "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()})
    (ROOT / "sha256-manifest.json").write_text(json.dumps({"files": manifest}, indent=2) + "\n")
    print(json.dumps(result, indent=2))

if __name__ == "__main__":
    main()
