#!/usr/bin/env python3
"""Independently audit original Git commit bytes and frozen all-ref scope.

Reads scratch evidence only. Never opens a repository, changes Git configuration,
or writes refs. Output is a derived JSON verification record in this directory.
"""
from __future__ import annotations
import gzip
import hashlib
import json
import re
from collections import Counter, defaultdict, deque
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
BOT = "github-actions[bot] <41898282+github-actions[bot]@users.noreply.github.com>"
SOURCE_MAIN = "b6fa111a53e4395875febd2379aa719e96d1179f"
HEX = re.compile(rb"[0-9a-f]{40}")

def parse_identity(raw):
    m = re.fullmatch(r"(.*) (-?\d+) ([+-]\d{4})", raw)
    assert m, raw
    return m.group(1), int(m.group(2)), m.group(3)

def parse_batch(raw):
    cursor = 0
    records = {}
    while cursor < len(raw):
        end = raw.index(b"\n", cursor)
        sha, kind, count = raw[cursor:end].split()
        assert HEX.fullmatch(sha) and kind == b"commit"
        size = int(count)
        begin = end + 1
        finish = begin + size
        body = raw[begin:finish]
        assert len(body) == size and raw[finish:finish+1] == b"\n"
        digest = hashlib.sha1(b"commit " + str(size).encode() + b"\0" + body).hexdigest()
        assert digest == sha.decode(), (digest, sha)
        assert digest not in records
        header, separator, message = body.partition(b"\n\n")
        assert separator
        entries = []
        for line in header.split(b"\n"):
            if line.startswith(b" "):
                assert entries
                entries[-1][1] += b"\n" + line
            else:
                key, space, value = line.partition(b" ")
                assert space
                entries.append([key, value])
        grouped = defaultdict(list)
        for key, value in entries:
            grouped[key].append(value)
        assert len(grouped[b"tree"]) == len(grouped[b"author"]) == len(grouped[b"committer"]) == 1
        tree = grouped[b"tree"][0]
        parents = grouped[b"parent"]
        assert HEX.fullmatch(tree) and all(HEX.fullmatch(p) for p in parents)
        author_raw = grouped[b"author"][0].decode("utf-8")
        committer_raw = grouped[b"committer"][0].decode("utf-8")
        records[digest] = {
            "sha": digest, "tree": tree.decode(), "parents": [p.decode() for p in parents],
            "author_raw": author_raw, "committer_raw": committer_raw,
            "author_identity": parse_identity(author_raw)[0],
            "committer_identity": parse_identity(committer_raw)[0],
            "signed": bool(grouped[b"gpgsig"] or grouped[b"gpgsig-sha256"]),
            "message": message.decode("utf-8"),
        }
        cursor = finish + 1
    assert cursor == len(raw)
    return records

def ancestors(records, tips):
    reached = set()
    stack = list(tips)
    while stack:
        sha = stack.pop()
        if sha in reached:
            continue
        assert sha in records, sha
        reached.add(sha)
        stack.extend(records[sha]["parents"])
    return reached

def main():
    raw_path = ROOT / "all-ref-commit-objects.batch.gz"
    records = parse_batch(gzip.decompress(raw_path.read_bytes()))
    refs = json.loads((ROOT / "all-ref-snapshot.json").read_text())
    expected = json.loads((ROOT / "all-ref-summary.json").read_text())
    saved_headers = json.loads(gzip.decompress((ROOT / "all-ref-commit-headers.json.gz").read_bytes()))
    assert len(records) == len(saved_headers) == len({x["sha"] for x in saved_headers}) == 1729
    assert len(refs) == len({r["ref"] for r in refs}) == 331
    branches = [r for r in refs if r["ref"].startswith("refs/audit/heads/")]
    tags = [r for r in refs if r["ref"].startswith("refs/audit/tags/")]
    assert len(branches) == 315 and len(tags) == 16 and len(branches) + len(tags) == len(refs)
    assert all(p in records for c in records.values() for p in c["parents"])
    assert ancestors(records, [r["sha"] for r in refs]) == set(records)

    children = defaultdict(list)
    pending = {}
    for c in records.values():
        pending[c["sha"]] = len(c["parents"])
        for parent in c["parents"]:
            children[parent].append(c["sha"])
    queue = deque(sha for sha, n in pending.items() if n == 0)
    affected = {}
    while queue:
        sha = queue.popleft()
        c = records[sha]
        affected[sha] = (
            c["author_identity"] == BOT or c["committer_identity"] == BOT
            or any(affected[p] for p in c["parents"])
        )
        for child in children[sha]:
            pending[child] -= 1
            if pending[child] == 0:
                queue.append(child)
    assert len(affected) == len(records), "Commit graph is not a closed DAG"
    for c in saved_headers:
        actual = records[c["sha"]]
        for field in ("sha", "tree", "parents", "author_raw", "committer_raw", "signed"):
            assert c[field] == actual[field], (c["sha"], field)
        assert c["would_change"] == affected[c["sha"]], c["sha"]

    authors = Counter(c["author_identity"] for c in records.values())
    committers = Counter(c["committer_identity"] for c in records.values())
    author_bot = {c["sha"] for c in records.values() if c["author_identity"] == BOT}
    committer_bot = {c["sha"] for c in records.values() if c["committer_identity"] == BOT}
    actual = {
        "branch_count": len(branches), "tag_count": len(tags), "unique_commits": len(records),
        "bot_author": len(author_bot), "bot_committer": len(committer_bot),
        "any_bot_identity": len(author_bot | committer_bot),
        "rewritten_commits_if_all_refs_rewritten": sum(affected.values()),
        "affected_branch_tips": sum(affected[r["sha"]] for r in branches),
        "affected_tag_tips": sum(affected[r["sha"]] for r in tags),
        "authors": dict(authors), "committers": dict(committers),
    }
    assert all(expected[k] == v for k, v in actual.items()), actual
    assert author_bot == committer_bot and len(author_bot) == 922
    main = ancestors(records, [SOURCE_MAIN])
    assert len(main) == 972 and len(main & author_bot) == 600
    assert sum(affected[s] for s in main) == 922
    api = json.loads((ROOT / "main-commits.json").read_text())
    assert {c["sha"] for c in api["commits"]} == main
    for c in api["commits"]:
        raw = records[c["sha"]]
        assert c["tree_sha"] == raw["tree"] and c["parents"] == raw["parents"]
        for field in ("author", "committer"):
            identity, timestamp, _zone = parse_identity(raw[field + "_raw"])
            assert identity == c[field]["name"] + " <" + c[field]["email"] + ">"
            observed = datetime.fromtimestamp(timestamp, timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
            assert observed == c[field]["date"]

    codex = [c for c in records.values() if c["author_identity"] == "Codex <codex@openai.com>" or c["committer_identity"] == "Codex <codex@openai.com>"]
    assert len(codex) == 1
    cc = codex[0]
    assert cc["sha"] == "6fbee6051b0a2f61cf69b22e35a5e914650ab0c7" and cc["sha"] not in main
    signed = [{"sha": c["sha"], "would_change": affected[c["sha"]]} for c in records.values() if c["signed"]]
    assert sorted(signed, key=lambda x: x["sha"]) == sorted(expected["signatures"], key=lambda x: x["sha"])
    result = {
        "status": "passed",
        "verified_at_utc": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "source_main_sha": SOURCE_MAIN,
        "checks": {
            "raw_commit_object_sha1": len(records),
            "batch_records_parsed_without_trailing_bytes": True,
            "all_parent_edges_resolved": True,
            "all_refs_resolve_to_saved_commits": True,
            "exact_ref_reachable_graph_no_extra_objects": True,
            "saved_projected_headers_match_raw_objects": len(records),
            "saved_affected_flags_independently_recomputed": len(records),
            "main_api_metadata_matches_raw_git_parents_trees_identities_timestamps": len(main),
        },
        "counts": actual,
        "main_only": {"commits": len(main), "bot_commits": len(main & author_bot), "changed_commits": sum(affected[s] for s in main)},
        "bot_author_only": len(author_bot - committer_bot),
        "bot_committer_only": len(committer_bot - author_bot),
        "codex_commit": {
            "sha": cc["sha"], "subject": cc["message"].split("\n")[0],
            "author_raw": cc["author_raw"], "committer_raw": cc["committer_raw"],
            "in_main_ancestry": False,
            "identity_in_scope": False,
            "hash_would_change_in_all_ref_rewrite_due_to_ancestor": affected[cc["sha"]],
            "exact_tip_refs": [r["ref"] for r in refs if r["sha"] == cc["sha"]],
        },
        "signature_headers": signed,
        "limits": [
            "Checks commit-object hashes and graph/identity metadata only; tree:0 snapshot does not include file or tree objects.",
            "Signature presence is checked from raw headers; this script does not cryptographically verify PGP signatures.",
            "Scope is the frozen original 315 branch and 16 tag tips, not later preparation branches or hidden pull-request refs.",
            "Codex identity is outside the requested github-actions[bot] correction and must be preserved."
        ],
        "repository_ref_config_or_source_mutations": 0,
        "input_hashes": [
            {"path": name, "sha256": hashlib.sha256((ROOT / name).read_bytes()).hexdigest(), "bytes": (ROOT / name).stat().st_size}
            for name in ("all-ref-summary.json", "all-ref-snapshot.json", "all-ref-commit-headers.json.gz", "all-ref-commit-objects.batch.gz", "main-commits.json")
        ],
    }
    output = ROOT / "all-ref-independent-verification.json"
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"status": result["status"], "counts": actual, "main_only": result["main_only"], "codex_commit": result["codex_commit"], "output": str(output)}, ensure_ascii=False, indent=2))

if __name__ == "__main__":
    main()
