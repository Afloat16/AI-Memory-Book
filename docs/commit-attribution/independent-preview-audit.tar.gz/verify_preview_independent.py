#!/usr/bin/env python3
"""Independently verify a bot-attribution preview against actual raw Git objects.

This verifier does not import the preview generator or use its parser. It reads
commit objects and refs only; all written files go to --output-dir.
"""
from __future__ import annotations
import argparse
import gzip
import hashlib
import json
import os
import re
import subprocess
from datetime import datetime, timezone
from pathlib import Path

OLD_IDENTITY = b"github-actions[bot] <41898282+github-actions[bot]@users.noreply.github.com>"
NEW_IDENTITY = b"Afloat <ShuffleMonkey@163.com>"
SOURCE = "b6fa111a53e4395875febd2379aa719e96d1179f"
CANDIDATE = "234891619d7bed88ddf3fae37e7f3e1b14a808b6"
EXPECTED_TREE = "bb28f814e9676b22faf020e90193047cf5684ea5"
REMOVED_SIGNATURE = "a0961f29dcdf3801d063e6d69bacaa1bde99e318"
PREVIEW_REF = "refs/heads/maintenance/author-attribution-preview"
SHA = re.compile(rb"[0-9a-f]{40}")
IDENTITY = re.compile(rb"(.* <[^<>]*>)( -?[0-9]+ [+-][0-9]{4})")

def git(git_dir, arguments, request=None):
    env = dict(os.environ)
    env["GIT_NO_LAZY_FETCH"] = "1"
    return subprocess.run(
        ["git", "--git-dir=" + str(git_dir), *arguments],
        input=request, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        check=True, env=env,
    ).stdout

def object_batch(git_dir, shas):
    ordered = sorted(shas)
    raw = git(git_dir, ["cat-file", "--batch"], ("\n".join(ordered) + "\n").encode())
    cursor = 0
    records = {}
    for requested in ordered:
        end = raw.index(b"\n", cursor)
        actual_sha, kind, size_bytes = raw[cursor:end].split()
        assert actual_sha.decode() == requested and kind == b"commit"
        size = int(size_bytes)
        begin, finish = end + 1, end + 1 + size
        payload = raw[begin:finish]
        assert len(payload) == size and raw[finish:finish + 1] == b"\n"
        computed = hashlib.sha1(b"commit " + str(size).encode() + b"\0" + payload).hexdigest()
        assert computed == requested, requested
        records[requested] = payload
        cursor = finish + 1
    assert cursor == len(raw) and len(records) == len(ordered)
    return records, raw

def dissect(payload):
    separator = payload.find(b"\n\n")
    assert separator >= 0
    head, message = payload[:separator], payload[separator + 2:]
    # Preserve every byte in each header block, including signature continuations.
    blocks = []
    for line in head.split(b"\n"):
        if line.startswith(b" "):
            assert blocks
            blocks[-1] += b"\n" + line
        else:
            assert b" " in line
            blocks.append(line)
    fields = {}
    for block in blocks:
        key, value = block.split(b" ", 1)
        fields.setdefault(key, []).append(value)
    for key in (b"tree", b"author", b"committer"):
        assert len(fields.get(key, [])) == 1, key
    assert SHA.fullmatch(fields[b"tree"][0])
    parents = fields.get(b"parent", [])
    assert all(SHA.fullmatch(value) for value in parents)
    for role in (b"author", b"committer"):
        assert IDENTITY.fullmatch(fields[role][0])
    return {
        "blocks": blocks, "fields": fields, "message": message,
        "tree": fields[b"tree"][0].decode(),
        "parents": [value.decode() for value in parents],
    }

def closure(records, tip):
    reached, stack = set(), [tip]
    while stack:
        sha = stack.pop()
        if sha in reached:
            continue
        assert sha in records
        reached.add(sha)
        stack.extend(records[sha]["parents"])
    return reached

def read_refs(git_dir):
    raw = git(git_dir, ["for-each-ref", "--format=%(refname) %(objectname)"])
    pairs = [line.split(" ", 1) for line in raw.decode().splitlines()]
    assert len(pairs) == len({p[0] for p in pairs})
    return dict(pairs)

def digest_file(path):
    raw = path.read_bytes()
    return {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--git-dir", type=Path, required=True)
    parser.add_argument("--preview-dir", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    assert args.output_dir.resolve() != args.preview_dir.resolve()
    original_names = ("summary.json", "commit-map.json", "original-refs.json", "README.md", "sha256-manifest.json")
    original_hashes = {name: digest_file(args.preview_dir / name) for name in original_names}
    declared_manifest = json.loads((args.preview_dir / "sha256-manifest.json").read_text())
    assert set(declared_manifest) == set(original_names) - {"sha256-manifest.json"}
    for name, expected in declared_manifest.items():
        assert expected == original_hashes[name], name
    summary = json.loads((args.preview_dir / "summary.json").read_text())
    mapping_rows = json.loads((args.preview_dir / "commit-map.json").read_text())
    original_refs = json.loads((args.preview_dir / "original-refs.json").read_text())
    mapping = {r["old"]: r["new"] for r in mapping_rows}
    assert len(mapping_rows) == len(mapping) == len(set(mapping.values())) == 972
    assert mapping[SOURCE] == CANDIDATE
    assert summary["source_main_sha"] == SOURCE and summary["preview_sha"] == CANDIDATE
    assert summary["preview_ref"] == PREVIEW_REF
    refs_before = read_refs(args.git_dir)
    assert all(refs_before.get(k) == v for k, v in original_refs.items())
    assert {k: v for k, v in refs_before.items() if k not in original_refs} == {PREVIEW_REF: CANDIDATE}
    assert original_refs["refs/heads/main"] == SOURCE
    assert len(original_refs) == 332

    old_objects, old_batch = object_batch(args.git_dir, mapping)
    new_objects, new_batch = object_batch(args.git_dir, mapping.values())
    old = {sha: dissect(raw) for sha, raw in old_objects.items()}
    new = {sha: dissect(raw) for sha, raw in new_objects.items()}
    assert closure(old, SOURCE) == set(mapping)
    assert closure(new, CANDIDATE) == set(mapping.values())
    assert old[SOURCE]["tree"] == new[CANDIDATE]["tree"] == EXPECTED_TREE
    author_changed = committer_changed = identity_changed = changed = parents_changed = 0
    removed, preserved_signed = [], []
    object_evidence = []
    for row in mapping_rows:
        old_sha, new_sha = row["old"], row["new"]
        before, after = old[old_sha], new[new_sha]
        assert before["tree"] == after["tree"], old_sha
        assert before["message"] == after["message"], old_sha
        expected_parents = [mapping[p] for p in before["parents"]]
        assert after["parents"] == expected_parents, old_sha
        any_identity_change = False
        role_changes = {}
        for role in (b"author", b"committer"):
            before_raw, after_raw = before["fields"][role][0], after["fields"][role][0]
            old_match, new_match = IDENTITY.fullmatch(before_raw), IDENTITY.fullmatch(after_raw)
            assert old_match.group(2) == new_match.group(2), (old_sha, role, "timestamp/timezone")
            target = old_match.group(1) == OLD_IDENTITY
            if target:
                assert after_raw == NEW_IDENTITY + old_match.group(2), (old_sha, role)
            else:
                assert after_raw == before_raw, (old_sha, role, "nonbot identity")
            role_changes[role] = before_raw != after_raw
            assert role_changes[role] == target
            any_identity_change |= target
        assert role_changes[b"author"] == role_changes[b"committer"], old_sha
        author_changed += role_changes[b"author"]
        committer_changed += role_changes[b"committer"]
        identity_changed += any_identity_change
        expected_blocks = []
        signatures_before = []
        signatures_after = []
        for block in before["blocks"]:
            key, value = block.split(b" ", 1)
            if key in (b"gpgsig", b"gpgsig-sha256"):
                signatures_before.append(block)
                if old_sha == REMOVED_SIGNATURE:
                    continue
            if key == b"parent":
                block = key + b" " + mapping[value.decode()].encode()
            elif key in (b"author", b"committer"):
                m = IDENTITY.fullmatch(value)
                if m.group(1) == OLD_IDENTITY:
                    block = key + b" " + NEW_IDENTITY + m.group(2)
            expected_blocks.append(block)
        for block in after["blocks"]:
            key = block.split(b" ", 1)[0]
            if key in (b"gpgsig", b"gpgsig-sha256"):
                signatures_after.append(block)
        expected_payload = b"\n".join(expected_blocks) + b"\n\n" + before["message"]
        assert expected_payload == new_objects[new_sha], (old_sha, "unexpected raw-byte change")
        if old_sha == REMOVED_SIGNATURE:
            assert len(signatures_before) == 1 and not signatures_after
            assert signatures_before[0].startswith(b"gpgsig ")
            removed.append(old_sha)
        else:
            assert signatures_before == signatures_after
            if signatures_before:
                assert old_sha == new_sha and old_objects[old_sha] == new_objects[new_sha]
                preserved_signed.append(old_sha)
        is_changed = old_sha != new_sha
        is_parent_changed = before["parents"] != after["parents"]
        assert row["identity_changed"] == any_identity_change
        assert row["parents_changed"] == is_parent_changed
        assert row["signature_removed"] == (old_sha == REMOVED_SIGNATURE)
        changed += is_changed
        parents_changed += is_parent_changed
        object_evidence.append({
            "old": old_sha, "new": new_sha, "tree": before["tree"],
            "original_payload_sha256": hashlib.sha256(old_objects[old_sha]).hexdigest(),
            "candidate_payload_sha256": hashlib.sha256(new_objects[new_sha]).hexdigest(),
            "message_sha256": hashlib.sha256(before["message"]).hexdigest(),
            "identity_changed": any_identity_change, "parents_changed": is_parent_changed,
            "removed_signature": old_sha == REMOVED_SIGNATURE,
        })
    assert author_changed == committer_changed == identity_changed == 600
    assert changed == 922 and len(mapping) - changed == 50
    assert removed == [REMOVED_SIGNATURE]
    assert set(preserved_signed) == {
        "df356d670351de73e6529f6975fcfc5fe9f36d5a",
        "ce7837fb8db7c221f39e27a531f2383385782eb1",
    }
    assert summary["total_commits"] == len(mapping)
    assert summary["identity_changed_commits"] == identity_changed
    assert summary["author_changes"] == author_changed and summary["committer_changes"] == committer_changed
    assert summary["rewritten_commits"] == changed and summary["unchanged_commits"] == 50
    assert summary["removed_signature_original_commits"] == removed
    refs_after = read_refs(args.git_dir)
    assert refs_before == refs_after
    assert all(digest_file(args.preview_dir / name) == original_hashes[name] for name in original_names)

    args.output_dir.mkdir(parents=True, exist_ok=True)
    (args.output_dir / "original-main-commit-objects.batch.gz").write_bytes(gzip.compress(old_batch, mtime=0))
    (args.output_dir / "candidate-main-commit-objects.batch.gz").write_bytes(gzip.compress(new_batch, mtime=0))
    (args.output_dir / "object-comparisons.json.gz").write_bytes(
        gzip.compress((json.dumps(object_evidence, indent=2) + "\n").encode(), mtime=0)
    )
    result = {
        "status": "passed",
        "verified_at_utc": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "repository": "Afloat16/AI-Memory-Book",
        "source_main_sha": SOURCE, "preview_sha": CANDIDATE, "preview_ref": PREVIEW_REF,
        "source_tree": old[SOURCE]["tree"], "preview_tree": new[CANDIDATE]["tree"],
        "counts": {
            "commits": len(mapping), "old_and_new_raw_object_hash_checks": len(mapping) * 2,
            "author_changes": author_changed, "committer_changes": committer_changed,
            "identity_changed_commits": identity_changed,
            "sha_changed_commits": changed, "unchanged_commits": len(mapping) - changed,
            "parents_changed_commits": parents_changed,
            "trees_identical": len(mapping), "message_bytes_identical": len(mapping),
            "author_timestamp_timezone_suffixes_identical": len(mapping),
            "committer_timestamp_timezone_suffixes_identical": len(mapping),
            "only_allowlisted_raw_byte_changes": len(mapping),
            "preexisting_refs_unchanged": len(original_refs),
            "only_added_preview_ref": PREVIEW_REF,
            "preserved_original_branch_snapshots": sum(k.startswith("refs/audit/heads/") for k in original_refs),
            "preserved_original_tag_snapshots": sum(k.startswith("refs/audit/tags/") for k in original_refs),
        },
        "checks": {
            "actual_original_graph_closed_and_matches_map": True,
            "actual_candidate_graph_closed_and_matches_map": True,
            "ordered_parent_mapping_preserved": True,
            "all_nonbot_identity_fields_byte_identical": True,
            "raw_header_order_and_unrelated_metadata_preserved": True,
            "original_five_preview_files_unchanged": True,
            "existing_local_refs_unchanged_during_independent_verification": True,
        },
        "removed_signature_original_commits": removed,
        "unchanged_original_signed_commits": sorted(preserved_signed),
        "original_preview_file_hashes": original_hashes,
        "verifier_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "limits": [
            "Read-only comparison against actual raw commit objects in the isolated bare repository.",
            "The original 315 branch and 16 tag tip snapshots and local main remain unchanged; this script performs no remote write or remote-ref re-query.",
            "Tree IDs are exactly identical for each pair; file/tree payloads were not downloaded in the tree:0 metadata clone.",
            "Existing signature bytes are preserved only on unchanged objects; the specified invalidated signature is removed. PGP signatures are not cryptographically verified here.",
            "Only the fixed main ancestry is included. Off-main bot commits and the separate Codex identity are not reattributed."
        ],
        "repository_ref_config_or_source_mutations": 0,
    }
    (args.output_dir / "verification.json").write_text(json.dumps(result, indent=2) + "\n")
    output_manifest = {}
    for p in sorted(args.output_dir.iterdir()):
        if p.is_file() and p.name != "sha256-manifest.json":
            output_manifest[p.name] = digest_file(p)
    (args.output_dir / "sha256-manifest.json").write_text(json.dumps(output_manifest, indent=2) + "\n")
    print(json.dumps({key: result[key] for key in ("status", "source_main_sha", "preview_sha", "source_tree", "preview_tree", "counts", "removed_signature_original_commits", "unchanged_original_signed_commits")}, indent=2))

if __name__ == "__main__":
    main()
